Das Bild "Ergebnis.png" zeigt Ihnen Elemente in einem Seiten-Arrangement. Versuchen Sie diese Darstellung mit den Positionierungsmöglichkeiten in CSS abzubilden.



Wenn Sie später noch Lust haben: mit dem Wissen zu komplexeren Selektionsmöglichkeiten können Sie auch jetzt alle Level von [CSS Diner](https://flukeout.github.io) spielen.